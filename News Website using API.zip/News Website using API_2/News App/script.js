//API Used: http://newsapi.org/s/india-news-api
const container = document.querySelector(".container");
const optionsContainer = document.querySelector(".options-container");
// "in" stands for India
const country = "in";
const options = [
  "general",
  "entertainment",
  "health",
  "science",
  "sports",
  "technology",
];

//100 requests per day
let isLoading = false;

// Create cards from data
const generateUI = (articles) => {
  container.innerHTML = ""; // Clear previous content
  for (let item of articles) {
    let card = document.createElement("div");
    card.classList.add("news-card");
    card.innerHTML = `<div class="news-image-container">
    <img src="${item.urlToImage || "./newspaper.jpg"}" alt="" />
    </div>
    <div class="news-content">
      <div class="news-title">
        ${item.title}
      </div>
      <div class="news-description">
      ${item.description || item.content || ""}
      </div>
      <a href="${item.url}" target="_blank" class="view-button">Read More</a>
    </div>`;
    container.appendChild(card);
  }
};

// Fetch news for a specific category
const getNewsByCategory = async (category) => {
  isLoading = true;
  container.innerHTML = "<div class='spinner'></div>";
  let response = await fetch(`https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=e6825e31441342ffa9733464b2642f86`);
  isLoading = false;
  if (!response.ok) {
    alert("Data unavailable at the moment. Please try again later");
    return false;
  }
  let data = await response.json();
  generateUI(data.articles);
};

// Category Selection
const selectCategory = (e, category) => {
  if (isLoading) {
    alert("Please wait for the current news to load");
    return;
  }
  let options = document.querySelectorAll(".option");
  options.forEach((element) => {
    element.classList.remove("active");
  });
  e.target.classList.add("active");
  getNewsByCategory(category);
};

// Options Buttons
const createOptions = () => {
  optionsContainer.innerHTML = ""; // Clear previous content
  for (let i of options) {
    optionsContainer.innerHTML += `<button class="option ${
      i == "general" ? "active" : ""
    }" onclick="selectCategory(event,'${i}')">${i}</button>`;
  }
};

// Initialize the page
const init = () => {
  optionsContainer.innerHTML = "";
  createOptions(); // Call createOptions once to add all buttons
  options.forEach((category) => {
    getNewsByCategory(category);
  });
};
window.onload = () => {
  init();
};
